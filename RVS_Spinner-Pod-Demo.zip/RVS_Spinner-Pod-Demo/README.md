INTRODUCTION
=
This project is an ultra-simple demonstration of using [RVS_Spinner](https://riftvalleysoftware.com/work/open-source-projects/#RVS_Spinner) as a [CocoaPod](https://cocoapods.org).

USAGE
=
The podfile is already set up. If you were starting from scratch, your podfile should have:

    pod 'RVS_Spinner'
    
Applied to the executable target.

In order to run this, simply `cd` to the project directory:

    $cd [PATH]/RVS_Spinner-Pod-Demo
    
And execute a `pod install` on it:
    
    $pod install
    
Or  a `pod update`:
    
    $pod update
    
Which will result in output like this:

    Update all pods
    Updating local specs repositories
    Analyzing dependencies
    Downloading dependencies
    Installing RVS_Spinner (2.4.0)
    Generating Pods project
    Integrating client project
    Pod installation complete! There is 1 dependency from the Podfile and 1 total pod installed.
    
    [!] Automatically assigning platform `iOS` with version `12.0` on target `RVS_Spinner_Basic_Test_Harness` because no platform was specified. Please specify a platform for this target in your Podfile. See `https://guides.cocoapods.org/syntax/podfile.html#platform`.

Then build and run the `RVS_Spinner_Basic_Test_Harness` target.

LICENSE
=
MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


[The Great Rift Valley Software Company: https://riftvalleysoftware.com](https://riftvalleysoftware.com)
